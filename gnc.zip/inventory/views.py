from django.views.generic import ListView, DetailView,UpdateView,DeleteView  # DetailView'ı import ediyoruz
from django.views.generic.edit import CreateView
from django.urls import reverse_lazy
from django.contrib import messages
from django.shortcuts import redirect
from django.http import JsonResponse
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required
from django.views.generic import TemplateView
from django.db.models.functions import Coalesce
from django.http import JsonResponse



from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.messages.views import SuccessMessageMixin
from django.db.models import Q,F,Value,DecimalField,Sum
from .models import Product, Category, Brand, StockMovement,Supplier 
from .forms import ProductSearchForm,ProductForm,StockMovementForm,QuickProductForm 

class ProductListView(LoginRequiredMixin, ListView):
    model = Product
    template_name = 'inventory/product_list.html'
    context_object_name = 'products'
    paginate_by = 15

    def get_queryset(self):
        queryset = Product.active_objects.select_related('category', 'brand').order_by('-created_at')
        query = self.request.GET.get('query')
        category = self.request.GET.get('category')
        brand = self.request.GET.get('brand')

        if query:
            queryset = queryset.filter(
                Q(name__icontains=query) |
                Q(product_code__icontains=query) |
                Q(barcode_data__icontains=query)
            )
        
        if category:
            queryset = queryset.filter(category__slug=category)
        
        if brand:
            queryset = queryset.filter(brand__slug=brand)
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        all_products = Product.active_objects.all()
        total_products = all_products.count()
        
        # DEĞİŞİKLİK 1: Düşük stoklu ürünlerin listesini alalım
        low_stock_products_queryset = all_products.filter(quantity__gt=0, quantity__lte=F('min_stock_level'))
        low_stock_products_count = low_stock_products_queryset.count()
        
        out_of_stock_products_queryset = all_products.filter(quantity=0)
        out_of_stock_products_count = out_of_stock_products_queryset.count()
        
        in_stock_products = total_products - out_of_stock_products_count

        context['stats'] = {
            'total_products': total_products,
            'in_stock': in_stock_products,
            'low_stock': low_stock_products_count,
            'out_of_stock': out_of_stock_products_count,
            'out_of_stock_products': out_of_stock_products_queryset,
            # DEĞİŞİKLİK 2: Düşük stoklu ürün listesini context'e ekleyelim
            'low_stock_products': low_stock_products_queryset 
        }
        
        context['form'] = ProductSearchForm(self.request.GET)
        
        return context
    
class ProductDetailView(LoginRequiredMixin, DetailView):
    model = Product
    template_name = 'inventory/product_detail.html'
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        product = self.get_object()
        context['stock_movements'] = StockMovement.objects.filter(product=product).order_by('-timestamp')[:10]
        context['page_title'] = "Ürün Detayı"
        context['stock_movement_form'] = StockMovementForm()
        return context

    def post(self, request, *args, **kwargs):
        product = self.get_object()
        form = StockMovementForm(request.POST)
        if form.is_valid():
            new_movement = form.save(commit=False)
            new_movement.product = product
            # GÜNCELLENEN SATIR: İşlemi yapan kullanıcıyı kaydet
            new_movement.user = request.user
            new_movement.save()
            messages.success(request, 'Stok hareketi başarıyla eklendi.')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
        return redirect('inventory:product_detail', slug=product.slug)
    
class ProductLabelPrintView(LoginRequiredMixin, DetailView):
    model = Product
    template_name = 'inventory/product_label_print.html'
    context_object_name = 'product'
    
class ProductCreateView(LoginRequiredMixin, SuccessMessageMixin, CreateView):
    permission_required = 'inventory.add_product'
    model = Product
    form_class = ProductForm
    template_name = 'inventory/product_form.html' # Birazdan bu dosyayı oluşturacağız
    success_url = reverse_lazy('inventory:product_list') # Başarılı olunca ürün listesine yönlendir
    success_message = "Yeni ürün başarıyla oluşturuldu."

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Yeni Ürün Ekle" # Şablonda başlık olarak kullanmak için
        return context
    
class ProductUpdateView(LoginRequiredMixin, SuccessMessageMixin, UpdateView):
    permission_required = 'inventory.change_product'

    model = Product
    form_class = ProductForm
    template_name = 'inventory/product_form.html' # Yeni ürün ekleme ile aynı şablonu kullanıyoruz
    success_message = "Ürün başarıyla güncellendi."

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Şablondaki başlığı dinamik olarak ayarlıyoruz
        context['page_title'] = f'"{self.object.name}" Ürününü Düzenle' 
        return context

    def get_success_url(self):
        # İşlem başarılı olunca güncellenen ürünün detay sayfasına yönlendir
        return reverse_lazy('inventory:product_detail', kwargs={'slug': self.object.slug})
    
class ProductDeleteView(LoginRequiredMixin, DeleteView):
    permission_required = 'inventory.delete_product'

    model = Product
    template_name = 'inventory/product_confirm_delete.html' # Birazdan bu dosyayı oluşturacağız
    success_url = reverse_lazy('inventory:product_list')
    context_object_name = 'product'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = f'"{self.object.name}" Ürününü Sil'
        return context

    def form_valid(self, form):
        # Ürün silinmeden önce başarılı mesajı gösterelim.
        messages.success(self.request, f'"{self.object.name}" adlı ürün başarıyla silindi.')
        return super().form_valid(form)
    
@login_required
@require_POST
def add_category_ajax(request):
    name = request.POST.get('name', None)
    if name:
        category, created = Category.objects.get_or_create(name=name)
        if created:
            return JsonResponse({'id': category.id, 'name': category.name})
    return JsonResponse({'error': 'İsim boş olamaz veya bu kategori zaten mevcut.'}, status=400)

@login_required
@require_POST
def add_brand_ajax(request):
    name = request.POST.get('name', None)
    if name:
        brand, created = Brand.objects.get_or_create(name=name)
        if created:
            return JsonResponse({'id': brand.id, 'name': brand.name})
    return JsonResponse({'error': 'İsim boş olamaz veya bu marka zaten mevcut.'}, status=400)

@login_required
@require_POST
def add_supplier_ajax(request):
    name = request.POST.get('name', None)
    if name:
        supplier, created = Supplier.objects.get_or_create(name=name)
        if created:
            return JsonResponse({'id': supplier.id, 'name': supplier.name})
    return JsonResponse({'error': 'İsim boş olamaz veya bu tedarikçi zaten mevcut.'}, status=400)

class ReportsView(LoginRequiredMixin, TemplateView):
    permission_required = 'inventory.view_product'
    template_name = 'inventory/reports.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Raporlar"

        # Genel Envanter Raporu
        total_value = Product.active_objects.annotate(
            line_total=Coalesce(F('quantity') * F('purchase_price'), Value(0), output_field=DecimalField())
        ).aggregate(
            total=Sum('line_total')
        )['total'] or 0

        context['total_inventory_value'] = total_value

        # En Çok Stoğa Sahip 5 Ürün
        context['most_stocked_products'] = Product.active_objects.order_by('-quantity')[:5]

        # Son 5 Stok Hareketi
        context['latest_movements'] = StockMovement.objects.all().order_by('-timestamp')[:5]
        
        return context
    
@login_required
@require_POST
def add_product_ajax(request):
    form = QuickProductForm(request.POST)
    if form.is_valid():
        # Yeni ürünün başlangıç stoğunu 0 olarak ayarlıyoruz.
        # Stok girişi daha sonra Stok Hareketi ile yapılmalı.
        product = form.save(commit=False)
        product.quantity = 0
        product.save()
        return JsonResponse({'id': product.id, 'name': product.name})
    else:
        return JsonResponse({'error': form.errors.as_json()}, status=400)