# inventory/models.py
# inventory/models.py
from django.db import models
from django.utils.text import slugify
from django.contrib.auth.models import User
from io import BytesIO
from django.core.files import File
import barcode # <-- BU SATIRI EKLEYİN
from barcode.writer import ImageWriter
from customers.models import Customer


# ... (ActiveProductManager ve diğer model sınıflarınız burada devam eder) ...

class ActiveProductManager(models.Manager):
    def get_queryset(self):
        # Bu yönetici çağrıldığında, varsayılan olarak sadece is_active=True olanları döndür.
        return super().get_queryset().filter(is_active=True)

class Category(models.Model):
    name = models.CharField(max_length=200, unique=True, verbose_name="Kategori Adı")
    slug = models.SlugField(max_length=220, unique=True, blank=True, help_text="Bu alan otomatik olarak doldurulacaktır (isteğe bağlı olarak değiştirilebilir).")
    parent = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL, # Üst kategori silinirse, alt kategori yetim kalır (bağlantısı kesilir), silinmez.
        null=True,
        blank=True,
        related_name='children', # Alt kategorilere parent.children ile erişim için
        verbose_name="Üst Kategori"
    )
    description = models.TextField(blank=True, null=True, verbose_name="Açıklama")
    is_active = models.BooleanField(default=True, verbose_name="Aktif mi?") # Kategoriyi pasif yapabilmek için

    class Meta:
        verbose_name = "Kategori"
        verbose_name_plural = "Kategoriler"
        ordering = ['name'] # Kategori adlarına göre sıralama

    def __str__(self):
        # Alt kategori ise "Üst Kategori > Alt Kategori" şeklinde gösterim
        full_path = [self.name]
        k = self.parent
        while k is not None:
            full_path.append(k.name)
            k = k.parent
        return ' > '.join(full_path[::-1]) # Ters çevirip birleştir

    def save(self, *args, **kwargs):
        if not self.slug: # Eğer slug boşsa veya None ise
            self.slug = slugify(self.name) # Kategori adından slug oluştur
        super().save(*args, **kwargs)

class Brand(models.Model):
    name = models.CharField(max_length=150, unique=True, verbose_name="Marka Adı")
    slug = models.SlugField(max_length=170, unique=True, blank=True, help_text="Bu alan otomatik olarak doldurulacaktır (isteğe bağlı olarak değiştirilebilir).")
    # logo = models.ImageField(upload_to='brand_logos/', blank=True, null=True, verbose_name="Marka Logosu") # İsteğe bağlı
    description = models.TextField(blank=True, null=True, verbose_name="Açıklama")
    is_active = models.BooleanField(default=True, verbose_name="Aktif mi?")

    class Meta:
        verbose_name = "Marka"
        verbose_name_plural = "Markalar"
        ordering = ['name']

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

class Supplier(models.Model):
    name = models.CharField(max_length=200, unique=True, verbose_name="Tedarikçi Adı")
    contact_person = models.CharField(max_length=150, blank=True, null=True, verbose_name="Yetkili Kişi")
    phone_number = models.CharField(max_length=20, blank=True, null=True, verbose_name="Telefon Numarası")
    email = models.EmailField(max_length=254, blank=True, null=True, verbose_name="E-posta Adresi")
    address = models.TextField(blank=True, null=True, verbose_name="Adres")
    notes = models.TextField(blank=True, null=True, verbose_name="Notlar")
    is_active = models.BooleanField(default=True, verbose_name="Aktif mi?")

    class Meta:
        verbose_name = "Tedarikçi"
        verbose_name_plural = "Tedarikçiler"
        ordering = ['name']

    def __str__(self):
        return self.name
    
class Product(models.Model):
    UNIT_CHOICES = [
        ('adet', 'Adet'),
        ('takim', 'Takım'),
        ('metre', 'Metre'),
        ('kg', 'Kilogram'),
        ('litre', 'Litre'),
        # İhtiyacınıza göre burayı genişletebilirsiniz
    ]

    name = models.CharField(max_length=255, verbose_name="Ürün Adı")
    slug = models.SlugField(max_length=280, unique=True, blank=True, help_text="Bu alan otomatik olarak doldurulacaktır.")
    category = models.ForeignKey(Category, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Kategori", related_name="products")
    brand = models.ForeignKey(Brand, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Marka", related_name="products")
    supplier = models.ForeignKey(Supplier, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Tedarikçi", related_name="products")

    product_code = models.CharField(max_length=100, unique=True, blank=True, null=True, verbose_name="Ürün Kodu (Stok Kodu)", help_text="Benzersiz ürün kodu. Boş bırakılırsa otomatik oluşturulabilir.")
    barcode_data = models.CharField(max_length=100, unique=True, blank=True, null=True, verbose_name="Barkod Verisi (EAN, Code128, QR içeriği)", help_text="Barkod içeriği. Genellikle ürün kodu ile aynı olabilir.")
    barcode_image = models.ImageField(upload_to='barcodes/', blank=True, null=True, verbose_name="Barkod Resmi")

    description = models.TextField(blank=True, null=True, verbose_name="Açıklama")
    image = models.ImageField(upload_to='product_images/', blank=True, null=True, verbose_name="Ürün Resmi")

    model_compatibility = models.CharField(max_length=255, blank=True, null=True, verbose_name="Model Uyumluluğu", help_text="Örn: Stihl MS250, MS230; Honda GX160")
    alternative_part_codes = models.CharField(max_length=255, blank=True, null=True, verbose_name="Alternatif Parça Kodları", help_text="Virgülle ayrılmış olarak giriniz.")

    purchase_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Alış Fiyatı (KDV Hariç)")
    selling_price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Satış Fiyatı (KDV Hariç)")
    # KDV oranı gibi alanlar da eklenebilir veya KDV'li fiyatlar ayrı tutulabilir.

    quantity = models.IntegerField(default=0, verbose_name="Mevcut Stok Miktarı", help_text="Bu alan stok hareketleriyle otomatik güncellenir.")
    min_stock_level = models.PositiveIntegerField(default=5, verbose_name="Minimum Stok Seviyesi", help_text="Bu seviyenin altına düşünce uyarı verilir.")
    unit = models.CharField(max_length=10, choices=UNIT_CHOICES, default='adet', verbose_name="Birim")

    location_in_store = models.CharField(max_length=100, blank=True, null=True, verbose_name="Mağaza İçi Konum (Raf vb.)")

    is_active = models.BooleanField(default=True, verbose_name="Aktif mi? (Satışta gösterilsin mi?)")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Oluşturulma Tarihi")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Güncellenme Tarihi")
    
    objects = models.Manager() # Varsayılan Django yöneticisi (tüm ürünleri getirir)
    active_objects = ActiveProductManager() # Bizim özel yöneticimiz (sadece aktifleri getirir)

    class Meta:
        verbose_name = "Ürün"
        verbose_name_plural = "Ürünler"
        ordering = ['name']
        indexes = [
            models.Index(fields=['slug']),
            models.Index(fields=['product_code']),
            models.Index(fields=['barcode_data']),
            models.Index(fields=['name']),
        ]

    def __str__(self):
        return f"{self.name} ({self.product_code or 'Kod Yok'})"

    def _generate_unique_slug(self):
        if not self.name: # İsim yoksa slug üretme
            return ""
        slug = slugify(self.name)
        unique_slug = slug
        num = 1
        while Product.objects.filter(slug=unique_slug).exists():
            unique_slug = f'{slug}-{num}'
            num += 1
        return unique_slug

    def _generate_product_code(self):
        # Basit bir ürün kodu üretme mantığı. İhtiyaca göre geliştirilebilir.
        # Örn: KategoriKodu-MarkaKodu-SıraNo
        # Şimdilik ilk 3 harf ve bir sayı dizisi:
        if self.name:
            prefix = self.name[:3].upper()
            last_product = Product.objects.filter(product_code__startswith=prefix).order_by('product_code').last()
            if last_product and last_product.product_code:
                try:
                    last_seq = int(last_product.product_code[len(prefix):])
                    new_seq = last_seq + 1
                    return f"{prefix}{str(new_seq).zfill(4)}"
                except ValueError:
                    pass # Hatalı formatta bir kod varsa
            return f"{prefix}{'0001'}"
        return None

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = self._generate_unique_slug()

        if not self.product_code and self.name: # Eğer ürün kodu boşsa ve isim varsa, otomatik üret
            self.product_code = self._generate_product_code()
            # Otomatik üretilen ürün kodu zaten benzersiz değilse, save işlemi hata verecektir (unique=True olduğu için).
            # Bu durumu daha iyi yönetmek için _generate_product_code içinde de benzersizlik kontrolü eklenebilir.

        if self.product_code and not self.barcode_data: # Barkod verisi boşsa ve ürün kodu varsa, ürün kodunu kullan
            self.barcode_data = self.product_code

        if self.barcode_data and not self.barcode_image: # Barkod verisi var ama resmi yoksa, barkod resmini oluştur
            try:
                BARCODE_TYPE = barcode.get_barcode_class('code128') # Code128 iyi bir seçenektir
                writer = ImageWriter()
                # Barkod resmini memory'de oluştur
                buffer = BytesIO()
                generated_barcode = BARCODE_TYPE(self.barcode_data, writer=writer)
                generated_barcode.write(buffer, options={'module_height': 10.0, 'font_size': 8, 'text_distance': 3.0, 'write_text': True})
                
                # ImageField'e kaydet
                file_name = f'{slugify(self.barcode_data)}.png'
                self.barcode_image.save(file_name, File(buffer), save=False) # save=False -> sonsuz döngüyü engeller
            except Exception as e:
                print(f"'{self.name}' için barkod oluşturma hatası: {e}")
                # Hata durumunda loglama veya kullanıcıya bildirim eklenebilir.

        super().save(*args, **kwargs) # Asıl kaydetme işlemini yap

    def is_low_stock(self):
        """Stok düşükse True döner."""
        return self.quantity <= self.min_stock_level


class StockMovement(models.Model):
    MOVEMENT_TYPES = [
        ('PURCHASE', 'Alım (Fatura Girişi)'),
        ('SALE', 'Satış'),
        ('RETURN_CUSTOMER', 'Müşteri İadesi'),
        ('RETURN_SUPPLIER', 'Tedarikçiye İade'),
        ('ADJUSTMENT_IN', 'Stok Giriş Düzeltme (Sayım Fazlası vb.)'),
        ('ADJUSTMENT_OUT', 'Stok Çıkış Düzeltme (Fire, Kayıp vb.)'),
        ('INITIAL_STOCK', 'Başlangıç Stoku'),
    ]
    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name='stock_movements', verbose_name="Ürün")
    movement_type = models.CharField(max_length=20, choices=MOVEMENT_TYPES, verbose_name="Hareket Tipi")
    quantity = models.IntegerField(verbose_name="Miktar", help_text="Giriş için pozitif, çıkış için pozitif (hareket tipi yönü belirler).")
    # Birim fiyatı burada da tutmak isteyebilirsiniz (hareket anındaki fiyat)
    # unit_price_at_movement = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, verbose_name="Hareket Anındaki Birim Fiyat")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name="İşlem Zamanı")
    notes = models.TextField(blank=True, null=True, verbose_name="Notlar/Açıklama")
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="İşlemi Yapan Kullanıcı")
    # İlgili satış veya alım faturasıyla bağlantı kurulabilir:
    # related_sale = models.ForeignKey('sales.Sale', on_delete=models.SET_NULL, null=True, blank=True)
    # related_purchase_order = models.ForeignKey('purchases.PurchaseOrder', on_delete=models.SET_NULL, null=True, blank=True)
    
    customer = models.ForeignKey(
        Customer, 
        on_delete=models.SET_NULL, # Müşteri silinirse satış kaydı silinmesin
        null=True, 
        blank=True, 
        verbose_name="İlişkili Müşteri"
    )

    class Meta:
        verbose_name = "Stok Hareketi"
        verbose_name_plural = "Stok Hareketleri"
        ordering = ['-timestamp', '-id'] # En son hareketler üstte

    def __str__(self):
        return f"{self.timestamp.strftime('%d-%m-%Y %H:%M')} - {self.product.name} - {self.get_movement_type_display()} ({self.quantity} {self.product.unit})"

# Django Sinyalleri: Stok hareketlerine göre ürün miktarını güncellemek için
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

@receiver(post_save, sender=StockMovement)
def update_product_quantity_on_save(sender, instance, created, **kwargs):
    """
    Yeni bir Stok Hareketi kaydedildiğinde veya mevcut bir hareket güncellendiğinde (genelde güncellenmemeli)
    ilgili ürünün stok miktarını günceller.
    """
    if created: # Sadece yeni hareket oluşturulduğunda çalışsın
        product = instance.product
        if instance.movement_type in ['PURCHASE', 'RETURN_CUSTOMER', 'ADJUSTMENT_IN', 'INITIAL_STOCK']:
            product.quantity += instance.quantity
        elif instance.movement_type in ['SALE', 'RETURN_SUPPLIER', 'ADJUSTMENT_OUT']:
            product.quantity -= instance.quantity
        else: # Bilinmeyen hareket tipi, logla veya hata ver
            pass
        product.save(update_fields=['quantity', 'updated_at'])

# Stok hareketi silindiğinde (genellikle önerilmez, ters kayıt atılmalı) miktarı geri almak için:
# Bu sinyali dikkatli kullanın. Genellikle stok hareketlerinin silinmesi yerine
# düzeltme kaydı (ters hareket) girilmesi daha iyi bir muhasebe pratiğidir.
@receiver(post_delete, sender=StockMovement)
def update_product_quantity_on_delete(sender, instance, **kwargs):
    """
    Bir Stok Hareketi silindiğinde (dikkatli kullanılmalı!) ilgili ürünün stok miktarını tersine çevirir.
    """
    product = instance.product
    if instance.movement_type in ['PURCHASE', 'RETURN_CUSTOMER', 'ADJUSTMENT_IN', 'INITIAL_STOCK']:
        product.quantity -= instance.quantity # Ekleneni geri al
    elif instance.movement_type in ['SALE', 'RETURN_SUPPLIER', 'ADJUSTMENT_OUT']:
        product.quantity += instance.quantity # Çıkarılanı geri ekle
    else:
        pass
    product.save(update_fields=['quantity', 'updated_at'])