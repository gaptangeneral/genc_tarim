# inventory/admin.py
from django.contrib import admin
from django.db.models import F
from .models import Category, Brand, Supplier, Product, StockMovement # Product ve StockMovement'ı import ettik

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'parent', 'slug', 'is_active')
    list_filter = ('is_active', 'parent')
    search_fields = ('name', 'description')
    prepopulated_fields = {'slug': ('name',)}
    ordering = ('name',)

@admin.register(Brand)
class BrandAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'description')
    prepopulated_fields = {'slug': ('name',)}
    ordering = ('name',)

@admin.register(Supplier)
class SupplierAdmin(admin.ModelAdmin):
    list_display = ('name', 'contact_person', 'phone_number', 'email', 'is_active')
    list_filter = ('is_active',)
    search_fields = ('name', 'contact_person', 'email', 'phone_number')
    ordering = ('name',)

class LowStockFilter(admin.SimpleListFilter):
    title = 'Düşük Stok Durumu' # Filtrenin başlığı
    parameter_name = 'low_stock_status' # URL'de kullanılacak parametre adı

    def lookups(self, request, model_admin):
        """
        Filtre seçeneklerini döndürür.
        Bir tuple listesi olmalı: (değer, görünen_ad)
        """
        return (
            ('yes', 'Evet - Düşük Stokta'),
            ('no', 'Hayır - Yeterli Stok'),
        )

    def queryset(self, request, queryset):
        """
        Seçilen değere göre queryset'i filtreler.
        """
        if self.value() == 'yes': # Eğer 'Evet - Düşük Stokta' seçildiyse
            # quantity <= min_stock_level olan ürünleri getir
            return queryset.filter(quantity__lte=F('min_stock_level'))
        if self.value() == 'no': # Eğer 'Hayır - Yeterli Stok' seçildiyse
            # quantity > min_stock_level olan ürünleri getir
            return queryset.filter(quantity__gt=F('min_stock_level'))
        # Eğer bir değer seçilmediyse, tüm queryset'i döndür (değişiklik yapma)
        return queryset


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = (
        'name', 'product_code', 'category', 'brand',
        'quantity', 'min_stock_level', 'selling_price', 'is_active', 
        'is_low_stock', # Bu metot hala listede görünebilir
        'updated_at'
    )
    list_filter = (
        'is_active', 
        'category', 
        'brand', 
        LowStockFilter # <-- Özel filtremizi buraya ekledik
    )
    search_fields = (
        'name', 'product_code', 'barcode_data',
        'description', 'model_compatibility', 'alternative_part_codes'
    )
    readonly_fields = ('quantity', 'created_at', 'updated_at', 'barcode_image_display')
    prepopulated_fields = {'slug': ('name',)}
    ordering = ('name',)
    list_per_page = 25

    fieldsets = (
        (None, {
            'fields': ('name', 'slug', 'is_active')
        }),
        ('Temel Bilgiler', {
            'fields': ('category', 'brand', 'supplier', 'product_code', 'barcode_data', 'barcode_image_display', 'barcode_image', 'image')
        }),
        ('Detaylar ve Uyumluluk', {
            'fields': ('description', 'model_compatibility', 'alternative_part_codes')
        }),
        ('Fiyat ve Stok', {
            'fields': ('purchase_price', 'selling_price', 'unit', 'min_stock_level', 'quantity', 'location_in_store')
        }),
        ('Tarihçe', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

    def barcode_image_display(self, obj):
        from django.utils.html import format_html
        if obj.barcode_image:
            return format_html('<img src="{}" width="150" height="auto" />', obj.barcode_image.url)
        return "Barkod resmi yok"
    barcode_image_display.short_description = "Barkod Resmi (Önizleme)"



@admin.register(StockMovement)
class StockMovementAdmin(admin.ModelAdmin):
    list_display = ('timestamp', 'product_link', 'movement_type', 'quantity_display', 'user_display', 'notes')
    list_filter = ('movement_type', 'timestamp', 'user')
    search_fields = ('product__name', 'product__product_code', 'notes', 'user__username')
    autocomplete_fields = ['product', 'user'] # Ürün ve kullanıcı seçimi için arama kutusu
    ordering = ('-timestamp',)
    list_per_page = 30
    # Stok hareketleri genellikle doğrudan admin panelinden çok fazla değiştirilmez,
    # bu yüzden readonly_fields eklenebilir veya sadece listeleme ve filtreleme amaçlı tutulabilir.
    # fields = ('product', 'movement_type', 'quantity', 'notes', 'user') # Ekleme/Düzenleme formu için

    def product_link(self, obj):
        from django.urls import reverse
        from django.utils.html import format_html
        link = reverse("admin:inventory_product_change", args=[obj.product.id])
        return format_html('<a href="{}">{}</a>', link, obj.product)
    product_link.short_description = 'Ürün'
    product_link.admin_order_field = 'product' # Ürün adına göre sıralama için

    def quantity_display(self, obj):
        return f"{obj.quantity} {obj.product.unit}"
    quantity_display.short_description = 'Miktar'
    quantity_display.admin_order_field = 'quantity'

    def user_display(self, obj):
        return obj.user.username if obj.user else "-"
    user_display.short_description = 'İşlemi Yapan'
    user_display.admin_order_field = 'user'