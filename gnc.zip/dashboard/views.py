from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.views.generic import TemplateView
from django.db.models import Sum, F
from inventory.models import Product
from customers.models import Customer
from service.models import ServiceRecord

class DashboardView(LoginRequiredMixin, UserPassesTestMixin, TemplateView):
    template_name = 'dashboard/index.html'

    def test_func(self):
        """
        Bu test fonksiyonu, sadece süper kullanıcıların bu view'ı çalıştırabilmesini sağlar.
        Eğer kullanıcı süper kullanıcı değilse, 403 Forbidden (Erişim Engellendi) hatası alır.
        """
        return self.request.user.is_superuser

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['page_title'] = "Ana Pano"

        # Ürün İstatistikleri
        products = Product.active_objects.all()
        context['total_products'] = products.count()
        context['low_stock_products'] = products.filter(quantity__gt=0, quantity__lte=F('min_stock_level')).count()
        context['out_of_stock_products'] = products.filter(quantity=0).count()

        # Müşteri ve Servis İstatistikleri
        context['total_customers'] = Customer.objects.filter(is_active=True).count()
        context['active_services'] = ServiceRecord.objects.exclude(status__in=['DELIVERED', 'CANCELLED']).count()

        # Son Hareketler Listeleri
        context['latest_products'] = Product.objects.order_by('-created_at')[:5]
        context['latest_services'] = ServiceRecord.objects.order_by('-created_at')[:5]
        
        # Grafik Verileri (bu kısım aynı kalıyor)
        # ... (grafik verilerini hesaplayan kodlarınız) ...

        return context