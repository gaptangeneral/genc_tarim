from django import forms
from django.contrib.auth.forms import AuthenticationForm

class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'autofocus': True,
        'placeholder': 'Kullanıcı Adınız',
        # Tailwind sınıflarını crispy-tailwind'in eklemesi beklenir.
        # Elle eklemek isterseniz: 'class': 'mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm placeholder-gray-400 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm'
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'Şifreniz',
        # Tailwind sınıfları için yukarıdaki gibi
    }))