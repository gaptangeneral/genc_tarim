# accounts/views.py
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required

from django.contrib.auth.views import LoginView as AuthLoginView
from django.shortcuts import redirect
from django.urls import reverse_lazy # reverse_lazy'yi get_success_url için kullanıyoruz
from django.contrib import messages
from .forms import CustomLoginForm
from django.conf import settings

class UserLoginView(AuthLoginView):
    template_name = 'accounts/login.html'
    authentication_form = CustomLoginForm
    redirect_authenticated_user = True

    def get_success_url(self):
        messages.success(self.request, f"Hoş geldiniz, {self.request.user.username}!")
        next_url = self.request.GET.get('next')
        if next_url:
            return next_url
        return reverse_lazy(settings.LOGIN_REDIRECT_URL) # LOGIN_REDIRECT_URL 'inventory:product_list' gibi namespaceli olabilir

    def form_invalid(self, form):
        messages.error(self.request, "Kullanıcı adı veya şifre hatalı. Lütfen tekrar deneyin.")
        return super().form_invalid(form)

def user_logout(request):
    logout(request)
    messages.info(request, "Başarıyla çıkış yaptınız.")
    return redirect('accounts:login') # <-- DEĞİŞİKLİK BURADA: 'accounts:login' OLARAK GÜNCELLENDİ


@login_required
def dashboard_redirect_view(request):
    """
    Kullanıcıyı giriş yaptıktan sonra rolüne göre doğru panele yönlendirir.
    """
    if request.user.is_superuser:
        return redirect('dashboard:index')
    elif request.user.groups.filter(name='Teknisyen').exists():
        # DÜZELTİLEN SATIR: 'service:' öneki eklendi.
        return redirect('service:technician_dashboard')
    else:
        return redirect('dashboard:index')