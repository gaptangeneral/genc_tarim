# accounts/urls.py
from django.urls import path
from .views import UserLoginView, user_logout
from . import views 
app_name = 'accounts' # Eğer namespace kullanmak isterseniz

urlpatterns = [
    path('login/', UserLoginView.as_view(), name='login'),
    path('logout/', user_logout, name='logout'),
    path('dashboard-redirect/', views.dashboard_redirect_view, name='dashboard_redirect'), # BU SATIRI EKLEYİN

]