from django import forms
from .models import ServiceRecord
from customers.models import Customer
from django.contrib.auth.models import User

class ServiceRecordForm(forms.ModelForm):
    # Müşteri alanını, arama yaparak seçilebilen bir alana dönüştürelim
    customer = forms.ModelChoiceField(
        queryset=Customer.objects.filter(is_active=True),
        widget=forms.Select(attrs={'class': 'select2-widget'}) # Select2 gibi bir kütüphane ile daha iyi çalışır
    )

    class Meta:
        model = ServiceRecord
        fields = [
            'customer', 'assigned_to', 'status',
            'machine_brand', 'machine_model', 'serial_number',
            'customer_complaint', 'technician_notes'
        ]
        widgets = {
            'customer_complaint': forms.Textarea(attrs={'rows': 4}),
            'technician_notes': forms.Textarea(attrs={'rows': 4}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        original_style = 'w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
        
        for field_name, field in self.fields.items():
            if field_name != 'customer': # Select2 için özel stil kullanmayalım
                 field.widget.attrs.update({'class': original_style})

        # Personel listesini sadece aktif ve staff olanlarla dolduralım
        self.fields['assigned_to'].queryset = User.objects.filter(is_active=True, groups__name='Teknisyen')
        self.fields['assigned_to'].label_from_instance = lambda obj: f"{obj.get_full_name() or obj.username}"


class ServiceRecordFilterForm(forms.Form):
    query = forms.CharField(
        label="Arama",
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500',
            'placeholder': 'Müşteri adı, makine modeli, seri no...'
        })
    )
    status = forms.ChoiceField(
        choices=[('', 'Tüm Durumlar')] + ServiceRecord.STATUS_CHOICES,
        required=False,
        label="Durum",
        widget=forms.Select(attrs={
             'class': 'w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
        })
    )
    
    # service/forms.py

# ... (mevcut importlar ve formlar) ...
from .models import ServicePart
from inventory.models import Product

class ServicePartForm(forms.ModelForm):
    # Ürünleri arayarak bulmak için ModelChoiceField kullanıyoruz
    part = forms.ModelChoiceField(
        queryset=Product.active_objects.all(),
        label="Eklenecek Parça",
        widget=forms.Select(attrs={'class': 'w-full px-4 py-2 border border-gray-300 rounded-lg'})
    )

    class Meta:
        model = ServicePart
        fields = ['part', 'quantity']
        
class ServiceStatusUpdateForm(forms.ModelForm):
    class Meta:
        model = ServiceRecord
        fields = ['status'] # Sadece 'status' alanını içerecek
        labels = {
            'status': 'Yeni Servis Durumu'
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['status'].widget.attrs.update({
            'class': 'w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500'
        })