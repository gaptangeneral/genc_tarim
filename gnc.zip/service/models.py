# service/models.py

from django.db import models
from django.contrib.auth.models import User
from customers.models import Customer
from inventory.models import Product
import uuid

class ServiceRecord(models.Model):
    STATUS_CHOICES = [
        ('ACCEPTED', 'Kabul Edildi'),
        ('DIAGNOSIS', 'Arıza Tespiti Yapılıyor'),
        ('WAITING_FOR_PART', 'Parça Bekleniyor'),
        ('IN_REPAIR', 'Onarımda'),
        ('REPAIRED', 'Onarım Tamamlandı'),
        ('DELIVERED', 'Müşteriye Teslim Edildi'),
        ('CANCELLED', 'İptal Edildi'),
    ]

    # Temel Bilgiler
    service_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True, verbose_name="Servis ID")
    customer = models.ForeignKey(Customer, on_delete=models.PROTECT, verbose_name="Müşteri")
    assigned_to = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, verbose_name="Atanan Personel")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='ACCEPTED', verbose_name="Servis Durumu")

    # Makine Bilgileri
    machine_brand = models.CharField(max_length=100, verbose_name="Makine Markası")
    machine_model = models.CharField(max_length=100, verbose_name="Makine Modeli")
    serial_number = models.CharField(max_length=100, blank=True, verbose_name="Seri Numarası")

    # Problem ve Çözüm
    customer_complaint = models.TextField(verbose_name="Müşteri Şikayeti")
    technician_notes = models.TextField(blank=True, verbose_name="Teknisyen Notları / Yapılan İşlemler")

    # Tarihler
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Kabul Tarihi")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Son Güncelleme")
    completed_at = models.DateTimeField(null=True, blank=True, verbose_name="Tamamlanma Tarihi")

    class Meta:
        verbose_name = "Servis Kaydı"
        verbose_name_plural = "Servis Kayıtları"
        ordering = ['-created_at']

    def __str__(self):
        return f"Servis #{str(self.service_id)[:8]} - {self.customer}"

class ServicePart(models.Model):
    service_record = models.ForeignKey(ServiceRecord, on_delete=models.CASCADE, related_name='parts_used', verbose_name="Servis Kaydı")
    part = models.ForeignKey(Product, on_delete=models.PROTECT, verbose_name="Kullanılan Parça")
    quantity = models.PositiveIntegerField(default=1, verbose_name="Kullanılan Adet")
    price_at_time_of_use = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Kullanım Anındaki Fiyat")

    class Meta:
        verbose_name = "Kullanılan Servis Parçası"
        verbose_name_plural = "Kullanılan Servis Parçaları"

    def __str__(self):
        return f"{self.quantity} adet {self.part.name}"

    def save(self, *args, **kwargs):
        # Parça eklenirken, o anki satış fiyatını otomatik olarak kaydet
        if not self.id: # Sadece ilk oluşturulduğunda fiyatı al
            self.price_at_time_of_use = self.part.selling_price
        super().save(*args, **kwargs)


# SİNYAL: Serviste parça kullanıldığında envanterden düşmek için
from django.db.models.signals import post_save
from django.dispatch import receiver
from inventory.models import StockMovement

@receiver(post_save, sender=ServicePart)
def deduct_part_from_stock(sender, instance, created, **kwargs):
    if created: # Sadece yeni bir parça kaydı eklendiğinde çalışsın
        StockMovement.objects.create(
            product=instance.part,
            movement_type='SALE', # Satış gibi stoktan düşer
            quantity=instance.quantity,
            notes=f"Servis #{str(instance.service_record.service_id)[:8]} için kullanıldı.",
            user=None # Bu işlemi yapan kullanıcıyı buraya eklemek ileride iyi bir geliştirme olur
        )